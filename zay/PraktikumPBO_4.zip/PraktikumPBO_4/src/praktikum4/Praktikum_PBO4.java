/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package praktikum4;

/**
 *
 * @author acer
 */

public class Praktikum_PBO4 {

    public static void main(String[] args) {

        // Membuat objek dari class Kendaraan
        Kendaraan kendaraan = new Kendaraan("Toyota", 180, 1);
        Mobil mobil  = new Mobil("Mercedes",180 , 1, 4);

        // Menampilkan nama menggunakan getter
        System.out.println("Nama: " + kendaraan.getNama());

        // Menampilkan seluruh informasi kendaraan
        kendaraan.tampilkanInfoKendaraan();
    }
}
