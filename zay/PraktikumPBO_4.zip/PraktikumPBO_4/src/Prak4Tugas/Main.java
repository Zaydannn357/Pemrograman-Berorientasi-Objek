/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Prak4Tugas;

/**
 *
 * @author acer
 */
public class Main {

    public static void main(String[] args) {

        // Membuat objek Pekerja
        Pekerja pekerja = new Pekerja(
                "Aldebaran",
                25,
                "Programmer",
                8000000
        );

        // Menampilkan informasi pekerja
        System.out.println("Informasi Pekerja:");
        System.out.println(pekerja.toString());

        // Mengubah nama menggunakan setter
        pekerja.setNama("Nouval");

        // Menampilkan informasi setelah nama diubah
        System.out.println("\nSetelah nama diubah:");
        System.out.println(pekerja.toString());

        // Percobaan akses langsung atribut
        // pekerja.nama;       // ERROR karena private
        System.out.println("Usia: " + pekerja.usia);
        System.out.println("Pekerjaan: " + pekerja.pekerjaan);
        // pekerja.gaji;       // ERROR karena private
    }
}
