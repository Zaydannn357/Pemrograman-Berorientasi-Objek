/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Prak5Tugas;

/**
 *
 * @author acer
 */
public class Main1 {
    public static void main(String[] args) {

        System.out.println("=== DATA HEWAN ===");

        Kucing kucing = new Kucing("Merlin", "Kucing");
        kucing.tampilkanInfo();

        System.out.println();

        Anjing anjing = new Anjing("Hiro", "Anjing");
        anjing.tampilkanInfo();

        System.out.println();

        System.out.println("=== DATA KENDARAAN ===");

        Mobil mobil = new Mobil("Toyota", 180, 4, 4);
        mobil.tampilkanInfo();

        System.out.println();

        SepedaMotor motor = new SepedaMotor("Yamaha", 120, 2, "2-tak");
        motor.tampilkanInfo();
    }
}
