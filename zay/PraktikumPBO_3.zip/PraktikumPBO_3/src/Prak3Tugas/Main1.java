/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Prak3Tugas;

/**
 *
 * @author acer
 */
public class Main1 {
    public static void main(String[] args) {
        Mobil mobil1 = new Mobil("Toyota", "Honda", 2020);
        Mobil mobil2 = new Mobil("Avanza", "Mercedes-Benz", 2024);
        
        mobil1.displayInfo();
        System.out.println();

        mobil2.displayInfo();
    }
}
