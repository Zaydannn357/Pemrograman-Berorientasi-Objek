/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Prak6Tugas;

/**
 *
 * @author acer
 */
import java.util.ArrayList;
import java.util.List;

public class KeranjangBelanja {

    private List<Produk> daftarProduk = new ArrayList<>();

    public void tambahProduk(Produk produk) {
        daftarProduk.add(produk);
    }

    public double hitungTotal() {
        double total = 0;

        for (Produk produk : daftarProduk) {
            total += produk.harga - produk.hitungDiskon();
        }

        return total;
    }
}
