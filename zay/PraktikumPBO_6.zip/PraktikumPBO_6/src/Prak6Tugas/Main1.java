/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Prak6Tugas;

/**
 *
 * @author acer
 */
public class Main1 {

    public static void main(String[] args) {

        Produk buku = new Buku("Pemrograman Java", 100000);
        Produk elektronik = new Elektronik("Mouse Wireless", 200000);
        Produk pakaian = new Pakaian("Kaos", 150000);

        KeranjangBelanja keranjang = new KeranjangBelanja();

        keranjang.tambahProduk(buku);
        keranjang.tambahProduk(elektronik);
        keranjang.tambahProduk(pakaian);

        System.out.println("=================================");
        System.out.println("       KERANJANG BELANJA");
        System.out.println("=================================");

        System.out.println("Produk 1 : " + buku.getNama());
        System.out.println("Harga    : Rp " + buku.getHarga());
        System.out.println("Diskon   : Rp " + buku.hitungDiskon());
        System.out.println("---------------------------------");

        System.out.println("Produk 2 : " + elektronik.getNama());
        System.out.println("Harga    : Rp " + elektronik.getHarga());
        System.out.println("Diskon   : Rp " + elektronik.hitungDiskon());
        System.out.println("---------------------------------");

        System.out.println("Produk 3 : " + pakaian.getNama());
        System.out.println("Harga    : Rp " + pakaian.getHarga());
        System.out.println("Diskon   : Rp " + pakaian.hitungDiskon());
        System.out.println("---------------------------------");

        System.out.println("Total setelah diskon : Rp " 
                + keranjang.hitungTotal());

        System.out.println("=================================");
    }
}
