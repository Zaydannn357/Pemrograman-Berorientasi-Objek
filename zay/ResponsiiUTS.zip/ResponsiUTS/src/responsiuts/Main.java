/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package responsiuts;

/**
 *
 * @author acer
 */
public class Main {
    public static void main(String[] args) {

        System.out.println("=== DATA PRODUK ===");

        Produk produk1 = new Elektronik("Laptop", 15000000, 2);
        Produk produk2 = new Makanan("Snack", 15000, "2023-12-30");

        produk1.tampilkanInfo();

        System.out.println();

        produk2.tampilkanInfo();

        System.out.println();
        System.out.println("=== DATA PEGAWAI ===");

        Pegawai pegawai1 = new PegawaiTetap("Gustavio", 5000000, 1000000);
        Pegawai pegawai2 = new PegawaiKontrak("Zoya", 3000000, 12);

        pegawai1.tampilkanInfo();

        System.out.println();

        pegawai2.tampilkanInfo();
    }
}
